package com.example.sinergiaapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class RegistrationActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registration)

        val btnAsociar = findViewById<Button>(R.id.btnAsociar)
        val btnElegirActividad = findViewById<Button>(R.id.btnElegirActividad)

        btnAsociar.setOnClickListener {
            val intent = Intent(this, RegisterClientActivity::class.java)
            startActivity(intent)
        }

        btnElegirActividad.setOnClickListener {
            // De momento solo mostramos un mensaje, luego lo cambiamos por la pantalla real
            // Puedes implementar tu segunda pantalla después
        }
    }
}
